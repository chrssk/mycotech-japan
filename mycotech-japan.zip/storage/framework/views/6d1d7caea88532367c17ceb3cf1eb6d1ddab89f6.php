<div class="modal fade" id="exampleModal<?php echo e($item['id']); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('monitoring.Baglog')); ?> <?php echo e($item['BaglogCode']); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <table class="table">
                <tr>
                    <th><?php echo e(__('monitoring.MyleaCode')); ?></th>
                    <th><?php echo e(__('common.Quantity')); ?></th>
                </tr>
                <?php $__currentLoopData = $item['Mylea']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('MyleaProductionDetails', ['id'=>$data['id'],])); ?>"><?php echo e($data['MyleaCode']); ?></a></td>
                        <td><?php echo e($data['Total']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('common.Close')); ?></button>
        </div>
      </div>
    </div>
  </div><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Baglog/Partials/BaglogUsageDetail.blade.php ENDPATH**/ ?>