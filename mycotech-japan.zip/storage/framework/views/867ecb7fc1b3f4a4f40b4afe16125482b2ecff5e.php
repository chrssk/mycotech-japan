<div id="MyleaSummaryTitle">
    <h2><?php echo e(__('common.Summary')); ?></h2>
</div>

<div class="row mb-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <table width="100%"  style="font-size: 1.0rem;">
                    <tr>
                        <td width="50%"><?php echo e(__('common.Total')); ?> <?php echo e(__('common.InStock')); ?></td>
                        <td width="5%">:</td>
                        <td width="17%"><?php echo e($Data->sum('InStock')); ?></td>
                        <td><?php echo e(__('common.Pieces')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('common.Total')); ?> <?php echo e(__('common.Harvest')); ?></td>
                        <td>:</td>
                        <td><?php echo e($Data->sum('TotalHarvest')); ?></td>
                        <td><?php echo e(__('common.Pieces')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('common.TotalTray')); ?></td>
                        <td>:</td>
                        <td><?php echo e($Data->sum('TotalTray')); ?></td>
                        <td><?php echo e(__('common.Pieces')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('common.Contamination')); ?></td>
                        <td>:</td>
                        <td><?php echo e($Data->sum('TotalContamination')); ?></td>
                        <td><?php echo e(__('common.Pieces')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('common.ContaminationRate')); ?></td>
                        <td>:</td>
                        <td><?php if($Data->sum('TotalTray')): ?><?php echo e(round($Data->sum('TotalContamination')/$Data->sum('TotalTray')*100, 2)); ?><?php endif; ?></td>
                        <td>%</td>
                    </tr>
                </table>
            </div>
        </div>            
    </div>
</div><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Mylea/Partials/MonitoringSummary.blade.php ENDPATH**/ ?>