<?php 

return [
    'Home' => 'Home',
    'Baglog' => 'Baglog',
    'BaglogTitle' => 'Baglog Monitoring',
    'BaglogCode' => 'Baglog Code',

    'Mylea' => 'Mylea',
    'MyleaCode' => 'Mylea Code',
    'MyleaTitle' => 'Mylea Monitoring',
    'ProductionCode' => 'Production Code',
    'ContaminationData'=> 'Contamination Data',
    'HarvestData' => 'Harvest Data',
    
    'FinishGoodCode' => 'Finish Good Code',
    'FinishGoodData'=> 'Finish Good Data',
    
];