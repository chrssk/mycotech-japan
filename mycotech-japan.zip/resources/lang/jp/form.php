<?php
    return [
        'BaglogInputForm' => 'バッグログ入力フォーム',
        'MyleaProductionForm' => 'マイレア制作フォーム',
        'AddBaglog' => 'バッグログを追加',
        'ContaminationForm' => '汚染票',
        'ContaminationData' => '汚染データ',
        'HarvestForm' => '収穫フォーム',
        'FinishGoodForm' => '良いフォームを仕上げる',
        'DeleteBaglog'=> 'バッグログを削除',
        'DeleteBaglogConfirmation' => 'IDを持つバッグログを削除してもよろしいですか？',
        'DeleteMyleaHarvest' => 'マイレア・ハーベストを削除',
        'DeleteMyleaHarvestConfirmation' => 'マイレアハーベストのIDを削除してもよろしいですか',
        'DeleteMyleaContamination' => 'マイレア汚染の除去',
        'DeleteMyleaContaminationConfirmation' => '本当にID付きマイレア汚染を削除しますか',
        'DeleteFinishGood' => '良い仕上がりを削除する',
        'DeleteFinishGoodConfirmation'=> '本当にIDを削除したいですか',
    ];