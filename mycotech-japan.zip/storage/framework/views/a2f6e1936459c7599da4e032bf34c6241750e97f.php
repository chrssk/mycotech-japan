<div class="d-flex justify-content-end">
    <div class="col-1">
        <label for="lang" class="col-form-label">Language</label>
    </div>
    <div class="col-auto">
        <select onchange="changeLanguage(this.value)" class="form-select col-2">
            <option <?php echo e(session()->has('lang_code')?(session()->get('lang_code')=='en'?'selected':''):''); ?> value="en">English</option>
            <option <?php echo e(session()->has('lang_code')?(session()->get('lang_code')=='jp'?'selected':''):''); ?> value="jp">Japanese</option>
        </select>
    </div>
</div>
<script>
    function changeLanguage(lang){
        window.location='<?php echo e(url("change-language")); ?>/'+lang;
    }
</script><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Partials/LangOption.blade.php ENDPATH**/ ?>