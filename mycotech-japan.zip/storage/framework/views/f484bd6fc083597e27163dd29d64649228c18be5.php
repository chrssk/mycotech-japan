<div class="modal fade" id="DeleteModal<?php echo e($item['id']); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-l modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"> Mylea Contamination <?php echo e($item['MyleaCode']); ?> <?php echo e($Details['id']); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            Are you sure you want to delete this item?
        </div>
        <div class="modal-footer">
          <a href="<?php echo e(route('MyleaContaminationDelete', ['id'=>$item['id'], 'details'=>$Details['id']])); ?>" class="btn btn-danger float-auto">Delete</a>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div> 
      </div>
    </div>
  </div><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Mylea/Partials/DeleteConfirmContamination.blade.php ENDPATH**/ ?>