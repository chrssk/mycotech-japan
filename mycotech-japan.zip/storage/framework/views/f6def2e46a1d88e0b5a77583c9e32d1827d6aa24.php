<div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteConfirmationModalLabel"><?php echo e(__("form.DeleteBaglog")); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php echo e(__('form.DeleteBaglogConfirmation')); ?> <?php echo e($item['BaglogCode']); ?>?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('common.Close')); ?></button>
          <a class="btn btn-danger" href="<?php echo e(route('BaglogMonitoringDelete', ['id'=>$item['id'],])); ?>"><?php echo e(__("common.Delete")); ?></a>
        </div>
      </div>
    </div>
  </div><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Baglog/Partials/DeleteBaglogConfirmation.blade.php ENDPATH**/ ?>