

<?php $__env->startSection('content'); ?>
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('monitoring.Home')); ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('MyleaMonitoring')); ?>"><?php echo e(__('monitoring.MyleaTitle')); ?></a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('monitoring.HarvestData')); ?></li>
        </ol>
    </nav>
    <div class="row bg-white p-4 rounded">
        
        <div class="alertDiv">
            <?php if(session()->has('Success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('Success')); ?>

                </div>
            <?php elseif(session()->has('Error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('Error')); ?>

            </div>
            <?php endif; ?>
        </div>

        <h2><?php echo e(__('monitoring.Mylea')); ?> <?php echo e($Details->MyleaCode); ?> <?php echo e(__('monitoring.HarvestData')); ?></h2>
        <div id="ContaminationTable" class="bg-white">
            <table class="table table-white" >
                <tr class="text-center">
                    <th><?php echo e(__('common.Number')); ?></th>
                    <th><?php echo e(__('monitoring.BaglogCode')); ?></th>
                    <th><?php echo e(__('common.HarvestDate')); ?></th>
                    <th><?php echo e(__('common.Harvest')); ?></th>
                    <th><?php echo e(__('common.TotalFinishGood')); ?></th>
                    <th><?php echo e(__('common.Notes')); ?></th>
                    <th colspan="4"><?php echo e(__('common.Action')); ?></th>
                </tr>
                <?php $__currentLoopData = $Data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td> <?php echo e($item['id']); ?> </td>
                    <td> <?php echo e($item['BaglogCode']); ?> </td>
                    <td> <?php echo e($item['HarvestDate']); ?> </td>
                    <td> <?php echo e($item['Total']); ?> </td>
                    <td> <?php echo e($item['TotalFinishGood']); ?> </td>
                    <td> <?php echo e($item['Notes']); ?> </td>
                    
                    <td>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#DeleteModal<?php echo e($item['id']); ?>">
                            <?php echo e(__('common.Delete')); ?>

                        </button>
                        <?php echo $__env->make('Operator.Mylea.Partials.DeleteHarvestConfirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    </td>
                    <td><a href="<?php echo e(route('FinishGoodForm', ['id'=>$item['id'],])); ?>"><?php echo e(__('common.FinishGood')); ?></a></td>
                    <td><a href="<?php echo e(route('FinishGoodData', ['id'=>$item['id'],])); ?>"><?php echo e(__('monitoring.FinishGoodData')); ?></a></td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="d-flex justify-content-center">
                
            </div>
        </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Mylea/HarvestDetails.blade.php ENDPATH**/ ?>