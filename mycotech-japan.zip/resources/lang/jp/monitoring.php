<?php

return [
    'Home' => 'ホーム',
    'Baglog' => 'バッグログ',
    'BaglogTitle' => 'バッグログ・モニタリング',
    'BaglogCode' => 'バッグログ・コード',

    'Mylea' => 'ミレア',
    'MyleaCode' => 'ミレアコード',
    'MyleaTitle' => 'ミレアモニタリング',
    'ProductionCode' => 'プロダクション・コード',
    'ContaminationData'=> '汚染データ',
    'HarvestData' => '収穫データ',

    'FinishGoodCode' => 'グッド・コードの完成',
    'FinishGoodData'=> '良いデータを仕上げる',
];