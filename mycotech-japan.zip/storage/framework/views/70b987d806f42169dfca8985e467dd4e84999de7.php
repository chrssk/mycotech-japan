

<?php $__env->startSection('content'); ?>
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('monitoring.Home')); ?></a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('monitoring.MyleaTitle')); ?></li>
        </ol>
    </nav>
    <div class="row bg-white p-4 rounded">

        <div class="alertDiv">
            <?php if(session()->has('Success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('Success')); ?>

                </div>
            <?php elseif(session()->has('Error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('Error')); ?>

            </div>
            <?php endif; ?>
        </div>
        <?php echo $__env->make('Operator.Mylea.Partials.MonitoringSummary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h2><?php echo e(__("monitoring.MyleaTitle")); ?></h2>
        <div id="MonitoringTable" class="bg-white">
            <table class="table table-white" >
                <tr class="text-center">
                    <th><?php echo e(__("monitoring.ProductionCode")); ?></th>
                    <th><?php echo e(__("common.ProductionDate")); ?></th>
                    <th><?php echo e(__("common.TotalTray")); ?></th>
                    <th><?php echo e(__("common.UnderIncubation")); ?></th>
                    <th><?php echo e(__("common.Contamination")); ?></th>
                    <th><?php echo e(__("common.Harvest")); ?></th>
                    <th><?php echo e(__("common.FinishGood")); ?></th>
                    <th colspan="2"><?php echo e(__("common.Action")); ?></th>
                </tr>
                <?php $__currentLoopData = $Data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($item['MyleaCode']); ?></td>
                    <td><?php echo e($item['ProductionDate']); ?></td>
                    <td><?php echo e($item['TotalTray']); ?></td>
                    <td><?php echo e($item['InStock']); ?>  </td>
                    
                    <?php if($item['TotalContamination'] > 0): ?>
                        <td><a href="<?php echo e(route('MyleaContaminationData', ['id'=>$item['id'],])); ?>"><?php echo e($item['TotalContamination']); ?></a></td>
                    <?php else: ?>
                        <td><?php echo e($item['TotalContamination']); ?></td>
                    <?php endif; ?>
                    
                    <?php if($item['TotalHarvest'] > 0): ?>
                        <td><a href="<?php echo e(route('MyleaHarvestData', ['id'=>$item['id'],])); ?>"><?php echo e($item['TotalHarvest']); ?></a></td>
                    <?php else: ?>
                        <td><?php echo e($item['TotalHarvest']); ?></td>
                    <?php endif; ?>

                    <td><?php echo e($item['TotalFinishGood']); ?></td>
                    <td><a href="<?php echo e(route('MyleaProductionDetails', ['id'=>$item['id'],])); ?>" class="btn btn-primary"><?php echo e(__("common.Update")); ?></a></td>
                    <td><a href="<?php echo e(route('MyleaContaminationForm', ['id'=>$item['id'],])); ?>" class="btn btn-primary"><?php echo e(__("form.ContaminationForm")); ?></a></td>
                    <td><a href="<?php echo e(route('MyleaHarvestForm', ['id'=>$item['id'],])); ?>" class="btn btn-primary"><?php echo e(__("form.HarvestForm")); ?></a></td>
                
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo $Data->links(); ?>

            </div>
        </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Mylea/Monitoring.blade.php ENDPATH**/ ?>