

<?php $__env->startSection('content'); ?>
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('monitoring.Home')); ?></a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('form.MyleaProductionForm')); ?></li>
        </ol>
    </nav>
    <div class="row bg-white p-4 rounded">
        <?php echo e($Data); ?>


        <?php echo e($DataBaglog); ?>

        <div class="alertDiv">
            <?php if(session()->has('Success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('Success')); ?>

                </div>
            <?php elseif(session()->has('Error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('Error')); ?>

            </div>
            <?php endif; ?>
        </div>
        
        <h2><?php echo e(__('form.MyleaProductionForm')); ?></h2>
        <form action="<?php echo e(route('MyleaProductionSubmit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <input type="hidden" name="id" value="<?php echo e($Data['id']); ?>">  
              <label for="ProductionDate" class="form-label"><?php echo e(__('common.ProductionDate')); ?></label>
              <input type="date" class="form-control" id="ProductionDate" name="ProductionDate" value="<?php echo e($Data['ProductionDate']); ?>" required>
            </div>
            <div class="mb-3">
              <label for="TotalTray" class="form-label"><?php echo e(__('common.TotalTray')); ?></label>
              <input type="number" class="form-control" id="TotalTray" name="TotalTray" value="<?php echo e($Data['TotalTray']); ?>" required>
            </div>
            <table class="table table-bordered" id="dynamicAddRemove">
                <tr>
                    <th><?php echo e(__('monitoring.BaglogCode')); ?></th>
                    <th><?php echo e(__('common.Quantity')); ?></th>
                    <th></th>
                </tr>
                <?php $__currentLoopData = $DataBaglog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$dataBaglog2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <select name="data[<?php echo e($index); ?>][BaglogID]" class="form-select" id="BaglogCode">
                                <?php $__currentLoopData = $BaglogData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item['id']); ?>"
                                        <?php if($item['id'] == $dataBaglog2['BaglogID']): ?>
                                            selected
                                        <?php endif; ?>
                                    ><?php echo e($item['BaglogCode']); ?> <?php echo e(__('common.InStock')); ?> :<?php echo e($item['InStock']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td><input type="number" name="data[<?php echo e($index); ?>][Quantity]" class="form-control" value="<?php echo e($dataBaglog2['Total']); ?>"></td>
                        <td>
                            <?php if($index > 0): ?>
                                <button type="button" class="btn btn-outline-danger remove-input-field">Delete</button>
                            <?php else: ?>
                                <button type="button" name="add" id="dynamic-ar" class="btn btn-outline-primary"><?php echo e(__('form.AddBaglog')); ?></button>
                            <?php endif; ?>
                        </td>
                    </tr>        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table> 
            <button type="submit" class="btn btn-primary"><?php echo e(__('common.Submit')); ?></button> 
        </form>          
    </div>
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    
    <script type="text/javascript">
        var i = 0;
        $("#dynamic-ar").click(function () {
            ++i;
        $("#dynamicAddRemove").append('<tr><td><select name="data['+ i +'][BaglogID]" class="form-select" id="BaglogCode"><?php $__currentLoopData = $BaglogData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($item['id']); ?>"><?php echo e($item['BaglogCode']); ?> In Stock :<?php echo e($item['InStock']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><input type="number" name="data['+ i +'][Quantity]" class="form-control" /></td><td><button type="button" class="btn btn-outline-danger remove-input-field">Delete</button></td></tr>');
        });
        $(document).on('click', '.remove-input-field', function () {
            $(this).parents('tr').remove();
        });
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Mylea/EditProductionForm.blade.php ENDPATH**/ ?>