

<?php $__env->startSection('content'); ?>
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('monitoring.Home')); ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('MyleaMonitoring')); ?>"><?php echo e(__('monitoring.MyleaTitle')); ?></a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('form.HarvestForm')); ?></li>
        </ol>
    </nav>
    <div class="row bg-white p-4 rounded">
        

        <h2><?php echo e(__("monitoring.Mylea")); ?> <?php echo e($MyleaDetails->MyleaCode); ?> <?php echo e(__('form.HarvestForm')); ?></h2>
        <form action="<?php echo e(route('MyleaHarvestSubmit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <input type="hidden" class="form-control" id="MyleaID" name="MyleaID" value="<?php echo e($MyleaDetails->id); ?>">
            </div>
            <div class="mb-3">
              <label for="HarvestDate" class="form-label"><?php echo e(__('common.HarvestDate')); ?></label>
              <input type="date" class="form-control" id="HarvestDate" name="HarvestDate" required>
            </div>
            <table class="table table-bordered" id="dynamicAddRemove">
                <tr>
                    <th><?php echo e(__('monitoring.BaglogCode')); ?></th>
                    <th><?php echo e(__('common.Quantity')); ?></th>
                    <th><?php echo e(__('common.Notes')); ?></th>
                </tr>
                <tr>
                    <td>
                        <select name="data[0][BaglogID]" class="form-select" id="BaglogCode">
                            <?php $__currentLoopData = $BaglogData2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item['id']); ?>"><?php echo e($item['BaglogCode']); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" name="data[0][Quantity]" class="form-control" /></td>
                    <td><input type="text" name="data[0][Notes]" class="form-control" /></td>
                    <td><button type="button" name="add" id="dynamic-ar" class="btn btn-outline-primary"><?php echo e(__('form.AddBaglog')); ?></button></td>
                </tr>
            </table> 
            <button type="submit" class="btn btn-primary"><?php echo e(__('common.Submit')); ?></button> 
        </form>          
    </div>
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    
    <script type="text/javascript">
        var i = 0;
        $("#dynamic-ar").click(function () {
            ++i;
        $("#dynamicAddRemove").append('<tr><td><select name="data['+ i +'][BaglogID]" class="form-select" id="BaglogCode"><?php $__currentLoopData = $BaglogData2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($item['id']); ?>"><?php echo e($item['BaglogCode']); ?> </option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><input type="number" name="data['+ i +'][Quantity]" class="form-control" /></td><td><input type="text" name="data['+ i +'][Notes]" class="form-control" /></td><td><button type="button" class="btn btn-outline-danger remove-input-field">Delete</button></td></tr>');
        });
        $(document).on('click', '.remove-input-field', function () {
            $(this).parents('tr').remove();
        });
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Mylea/HarvestForm.blade.php ENDPATH**/ ?>