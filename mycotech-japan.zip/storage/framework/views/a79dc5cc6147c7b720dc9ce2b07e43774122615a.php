

<?php $__env->startSection('content'); ?>
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('monitoring.Home')); ?></a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('monitoring.BaglogTitle')); ?></li>
        </ol>
    </nav>
    <div class="row bg-white p-4 rounded">
        <div class="alertDiv">
            <?php if(session()->has('StatusUpdate')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('StatusUpdate')); ?>

                </div>
            <?php elseif(session()->has('StatusDeleted')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('StatusDeleted')); ?>

                </div>
            <?php endif; ?>
        </div>
        
        <h2><?php echo e(__("monitoring.BaglogTitle")); ?></h2>
        <div id="MonitoringTable" class="bg-white">
            <table class="table table-white" >
                <tr class="text-center">
                    <th><?php echo e(__("monitoring.BaglogCode")); ?></th>
                    <th><?php echo e(__("common.ArrivalDate")); ?></th>
                    <th><?php echo e(__("common.Quantity")); ?></th>
                    <th><?php echo e(__("monitoring.MyleaCode")); ?></th>
                    <th><?php echo e(__("common.UnderIncubation")); ?></th>
                    <th><?php echo e(__("common.Notes")); ?></th>
                    <th colspan="2"><?php echo e(__("common.Action")); ?></th>
                </tr>
                <?php $__currentLoopData = $Data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($item['id']); ?>">
                            <?php echo e($item['BaglogCode']); ?>

                        </button>
                        <?php echo $__env->make('Operator.Baglog.Partials.BaglogUsageDetail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                    <td><?php echo e($item['ArrivalDate']); ?></td>
                    <td><?php echo e($item['Quantity']); ?></td>
                    <td>
                        <?php $__currentLoopData = $item['Mylea']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($data['MyleaCode']); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td><?php echo e($item['InStock']); ?></td>
                    <td><?php echo e($item['Notes']); ?></td>
                    <td>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#updateModal<?php echo e($item['id']); ?>">
                            <?php echo e(__("common.Update")); ?>

                        </button>
                        <?php echo $__env->make('Operator.Baglog.Partials.UpdateBaglogPartials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                    <td>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal">
                            <?php echo e(__("common.Delete")); ?>

                        </button>
                        <?php echo $__env->make('Operator.Baglog.Partials.DeleteBaglogConfirmation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo $Data->links(); ?>

            </div>
        </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Baglog/Monitoring.blade.php ENDPATH**/ ?>