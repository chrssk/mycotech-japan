<?php
    return [
        'BaglogInputForm' => 'Baglog Input Form',
        'MyleaProductionForm' => 'Mylea Production Form',
        'AddBaglog' => 'Add Baglog',
        'ContaminationForm' => 'Contamination Form',
        'ContaminationData' => 'Contamination Data',
        'HarvestForm' => 'Harvest Form',
        'FinishGoodForm' => 'Finish Good Form',
        'DeleteBaglog'=> 'Delete Baglog',
        'DeleteBaglogConfirmation' => 'Are you sure you want to delete Baglog with ID',
        'DeleteMyleaHarvest' => 'Delete Mylea Harvest',
        'DeleteMyleaHarvestConfirmation' => 'Are you sure you want to delete Mylea Harvest with ID',
        'DeleteMyleaContamination' => 'Delete Mylea Contamination',
        'DeleteMyleaContaminationConfirmation' => 'Are you sure you want to delete Mylea Contamination with ID',
        'DeleteFinishGood' => 'Delete Finish Good',
        'DeleteFinishGoodConfirmation'=> 'Are you sure you want to delete Finish Good with ID',


    ];