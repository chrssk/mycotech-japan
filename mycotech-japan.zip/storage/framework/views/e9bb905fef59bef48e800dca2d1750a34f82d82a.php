

<?php $__env->startSection('content'); ?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('monitoring.Home')); ?></a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('form.BaglogInputForm')); ?></li>
        </ol>
    </nav>
    <div class="row bg-white p-4 rounded">
        <div class="alertDiv">
            <?php if(session()->has('StatusSubmit') && (session('StatusSubmit') == 'Data submitted')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('StatusSubmit')); ?>

                </div>
            <?php elseif(session()->has('StatusSubmit')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('StatusSubmit')); ?>

                </div>
            <?php endif; ?>
        </div>
        <h2><?php echo e(__('form.BaglogInputForm')); ?></h2>
        <form action="<?php echo e(route('BaglogSubmit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="ArrivalDate" class="form-label"><?php echo e(__('common.ArrivalDate')); ?></label>
              <input type="date" class="form-control" id="ArrivalDate" name="ArrivalDate" required>
            </div>
            <div class="mb-3">
              <label for="Quantity" class="form-label"><?php echo e(__('common.Quantity')); ?></label>
              <input type="number" class="form-control" id="Quantity" name="Quantity" required>
            </div>
            <div class="mb-3">
                <label for="Notes" class="form-label"><?php echo e(__('common.Notes')); ?></label>
                <input type="text" class="form-control" id="Notes" name="Notes">
            </div>
            <button type="submit" class="btn btn-primary"><?php echo e(__('common.Submit')); ?></button>
        </form>          
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Baglog/InputForm.blade.php ENDPATH**/ ?>