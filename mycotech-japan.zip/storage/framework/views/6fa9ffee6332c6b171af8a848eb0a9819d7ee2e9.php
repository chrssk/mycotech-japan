<div class="modal fade" id="DeleteModal<?php echo e($item['id']); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-l modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(__('form.DeleteMyleaContamination')); ?> </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <?php echo e(__('form.DeleteMyleaHarvestConfirmation')); ?><?php echo e($item['id']); ?> ?
        </div>
        <div class="modal-footer">
          <a href="<?php echo e(route('MyleaContaminationDelete', ['id'=>$item['id'], 'details'=>$Details['id']])); ?>" class="btn btn-danger float-auto"><?php echo e(__('common.Delete')); ?></a>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('common.Close')); ?></button>
        </div> 
      </div>
    </div>
  </div><?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Mylea/Partials/DeleteContaminationConfirm.blade.php ENDPATH**/ ?>