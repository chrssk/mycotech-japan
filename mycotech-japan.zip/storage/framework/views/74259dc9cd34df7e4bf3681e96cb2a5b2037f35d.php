<div class="modal fade" id="updateModal<?php echo e($item['id']); ?>" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateModalLabel"><?php echo e(__("monitoring.Baglog")); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('BaglogMonitoringUpdate')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                    <div class="mb-3">
                      <label for="ArrivalDate" class="form-label"><?php echo e(__("common.ArrivalDate")); ?></label>
                      <input type="date" class="form-control" id="ArrivalDate" name="ArrivalDate" value="<?php echo e($item['ArrivalDate']); ?>" required>
                    </div>
                    <div class="mb-3">
                      <label for="Quantity" class="form-label"><?php echo e(__("common.Quantity")); ?></label>
                      <input type="number" class="form-control" id="Quantity" name="Quantity" value="<?php echo e($item['Quantity']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="Notes" class="form-label"><?php echo e(__("common.Notes")); ?></label>
                        <input type="text" class="form-control" id="Notes" value="<?php echo e($item['Notes']); ?>" name="Notes">
                    </div> 
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__("common.Close")); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo e(__("common.Submit")); ?></button>
                </form>  
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\Mycotech\Project\Github-mycljapan\mycotech-japan\resources\views/Operator/Baglog/Partials/UpdateBaglogPartials.blade.php ENDPATH**/ ?>